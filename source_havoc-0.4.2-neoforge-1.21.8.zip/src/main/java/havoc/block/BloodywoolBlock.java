package havoc.block;

import net.neoforged.neoforge.common.util.DeferredSoundType;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

public class BloodywoolBlock extends Block {
	public BloodywoolBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(new DeferredSoundType(1.0f, 1.0f, () -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wool.break")), () -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.slime_block.step")),
				() -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("entity.slime.squish")), () -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wool.hit")),
				() -> BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wool.fall")))).strength(1f, 10f));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}
package havoc.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.Difficulty;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import javax.annotation.Nullable;

@EventBusSubscriber
public class ArmorweightProcedure {
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity().level(), event.getEntity());
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player && world.getDifficulty() == Difficulty.HARD) {
			if (4 < (entity instanceof LivingEntity _livEnt ? _livEnt.getArmorValue() : 0)) {
				if (entity.isInWater()) {
					{
						Entity _ent = entity;
						if (!_ent.level().isClientSide() && _ent.getServer() != null) {
							_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
									_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "title @s actionbar {\"text\":\"Your armor weights you down\",\"color\":\"aqua\"}");
						}
					}
					entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x()), ((-1) * 0.0125 * (entity instanceof LivingEntity _livEnt ? _livEnt.getArmorValue() : 0)), (entity.getDeltaMovement().z())));
				} else if (entity.isInLava()) {
					{
						Entity _ent = entity;
						if (!_ent.level().isClientSide() && _ent.getServer() != null) {
							_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
									_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "title @s actionbar {\"text\":\"Your armor weights you down\",\"color\":\"gold\"}");
						}
					}
					entity.setDeltaMovement(new Vec3((entity.getDeltaMovement().x()), ((-1.3) * 0.0125 * (entity instanceof LivingEntity _livEnt ? _livEnt.getArmorValue() : 0)), (entity.getDeltaMovement().z())));
				}
			}
		}
	}
}
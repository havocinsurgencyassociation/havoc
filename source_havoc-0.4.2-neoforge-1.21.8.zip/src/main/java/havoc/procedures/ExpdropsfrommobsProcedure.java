package havoc.procedures;

import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;

import javax.annotation.Nullable;

@EventBusSubscriber
public class ExpdropsfrommobsProcedure {
	@SubscribeEvent
	public static void onEntityDeath(LivingDeathEvent event) {
		if (event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double rng = 0;
		if (entity instanceof Monster || entity instanceof EnderDragon || entity instanceof Piglin) {
			rng = Mth.nextDouble(RandomSource.create(), 0, 2) + 8;
			if (entity instanceof EnderMan) {
				rng = Mth.nextDouble(RandomSource.create(), 0, 10) + 20;
			}
			if (entity instanceof WitherBoss) {
				rng = Mth.nextDouble(RandomSource.create(), 0, 10000) + 5000;
			}
			if (entity instanceof EnderDragon) {
				rng = Mth.nextDouble(RandomSource.create(), 0, 2000) + 10000;
			}
			if (50 < rng) {
				if (world instanceof ServerLevel _level)
					_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, (int) rng));
			} else {
				for (int index0 = 0; index0 < (int) rng; index0++) {
					if (world instanceof ServerLevel _level)
						_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 1));
				}
			}
		}
	}
}
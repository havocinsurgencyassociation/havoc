package havoc.item;

import net.minecraft.world.item.Item;

public class AcaciaScrapItem extends Item {
	public AcaciaScrapItem(Item.Properties properties) {
		super(properties);
	}
}
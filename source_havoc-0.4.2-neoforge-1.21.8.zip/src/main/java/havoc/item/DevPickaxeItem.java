package havoc.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

public class DevPickaxeItem extends Item {
	public DevPickaxeItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC).durability(999).enchantable(420));
	}

	@Override
	public float getDestroySpeed(ItemStack itemstack, BlockState state) {
		return 12f;
	}

	@Override
	public boolean isCorrectToolForDrops(ItemStack itemstack, BlockState state) {
		return true;
	}
}
package havoc.item;

import net.minecraft.world.item.Item;

public class BambooScrapItem extends Item {
	public BambooScrapItem(Item.Properties properties) {
		super(properties);
	}
}
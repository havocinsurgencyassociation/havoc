package havoc.item;

import net.minecraft.world.item.Item;

public class StrippedBamboItem extends Item {
	public StrippedBamboItem(Item.Properties properties) {
		super(properties);
	}
}
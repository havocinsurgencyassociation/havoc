package havoc.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class BraininfectedItem extends Item {
	public BraininfectedItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(1).saturationModifier(0f).alwaysEdible().build()));
	}
}
package havoc.item;

import net.minecraft.world.item.Item;

public class MangroveScrapItem extends Item {
	public MangroveScrapItem(Item.Properties properties) {
		super(properties);
	}
}
package havoc.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class DevToolItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 100, 20f, 0, 128000, TagKey.create(Registries.ITEM, ResourceLocation.parse("havoc:dev_tool_repair_items")));

	public DevToolItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 3f, 0f));
	}
}
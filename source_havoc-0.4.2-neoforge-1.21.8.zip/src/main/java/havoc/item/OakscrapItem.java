package havoc.item;

import net.minecraft.world.item.Item;

public class OakscrapItem extends Item {
	public OakscrapItem(Item.Properties properties) {
		super(properties);
	}
}
package havoc.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class PoopSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 10, 0f, 0, 1, TagKey.create(Registries.ITEM, ResourceLocation.parse("havoc:poop_sword_repair_items")));

	public PoopSwordItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 1f, -1f));
	}
}
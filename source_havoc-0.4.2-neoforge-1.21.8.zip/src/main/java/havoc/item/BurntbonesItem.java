package havoc.item;

import net.minecraft.world.item.Item;

public class BurntbonesItem extends Item {
	public BurntbonesItem(Item.Properties properties) {
		super(properties);
	}
}
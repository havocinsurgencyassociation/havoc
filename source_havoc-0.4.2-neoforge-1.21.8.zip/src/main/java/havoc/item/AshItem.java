package havoc.item;

import net.minecraft.world.item.Item;

public class AshItem extends Item {
	public AshItem(Item.Properties properties) {
		super(properties);
	}
}
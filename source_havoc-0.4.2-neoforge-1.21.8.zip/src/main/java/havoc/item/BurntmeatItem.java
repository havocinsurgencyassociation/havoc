package havoc.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class BurntmeatItem extends Item {
	public BurntmeatItem(Item.Properties properties) {
		super(properties.food((new FoodProperties.Builder()).nutrition(0).saturationModifier(0f).build()));
	}
}
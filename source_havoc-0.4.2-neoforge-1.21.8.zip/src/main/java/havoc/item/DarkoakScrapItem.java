package havoc.item;

import net.minecraft.world.item.Item;

public class DarkoakScrapItem extends Item {
	public DarkoakScrapItem(Item.Properties properties) {
		super(properties);
	}
}
package havoc.item;

import net.minecraft.world.item.Item;

public class MixedScrapItem extends Item {
	public MixedScrapItem(Item.Properties properties) {
		super(properties);
	}
}
package havoc.item;

import net.minecraft.world.item.Item;

public class CherrySticksItem extends Item {
	public CherrySticksItem(Item.Properties properties) {
		super(properties);
	}
}
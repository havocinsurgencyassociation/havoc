package havoc.item;

import net.minecraft.world.item.Item;

public class JungleScrapItem extends Item {
	public JungleScrapItem(Item.Properties properties) {
		super(properties);
	}
}
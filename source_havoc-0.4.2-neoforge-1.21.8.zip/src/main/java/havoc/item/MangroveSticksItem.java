package havoc.item;

import net.minecraft.world.item.Item;

public class MangroveSticksItem extends Item {
	public MangroveSticksItem(Item.Properties properties) {
		super(properties);
	}
}
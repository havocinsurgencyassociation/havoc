package havoc.item;

import net.minecraft.world.item.Item;

public class WarpedScrapItem extends Item {
	public WarpedScrapItem(Item.Properties properties) {
		super(properties);
	}
}
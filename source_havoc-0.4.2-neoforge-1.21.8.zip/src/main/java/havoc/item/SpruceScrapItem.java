package havoc.item;

import net.minecraft.world.item.Item;

public class SpruceScrapItem extends Item {
	public SpruceScrapItem(Item.Properties properties) {
		super(properties);
	}
}
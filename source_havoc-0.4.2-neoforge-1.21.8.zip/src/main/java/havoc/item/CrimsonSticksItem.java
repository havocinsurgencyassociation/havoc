package havoc.item;

import net.minecraft.world.item.Item;

public class CrimsonSticksItem extends Item {
	public CrimsonSticksItem(Item.Properties properties) {
		super(properties);
	}
}
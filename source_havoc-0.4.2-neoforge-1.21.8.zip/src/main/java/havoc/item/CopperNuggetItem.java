package havoc.item;

import net.minecraft.world.item.Item;

public class CopperNuggetItem extends Item {
	public CopperNuggetItem(Item.Properties properties) {
		super(properties);
	}
}
package havoc.item;

import net.minecraft.world.item.Item;

public class PlantStringItem extends Item {
	public PlantStringItem(Item.Properties properties) {
		super(properties);
	}
}
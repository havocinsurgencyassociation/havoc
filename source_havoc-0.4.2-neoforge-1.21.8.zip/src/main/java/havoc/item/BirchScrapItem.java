package havoc.item;

import net.minecraft.world.item.Item;

public class BirchScrapItem extends Item {
	public BirchScrapItem(Item.Properties properties) {
		super(properties);
	}
}
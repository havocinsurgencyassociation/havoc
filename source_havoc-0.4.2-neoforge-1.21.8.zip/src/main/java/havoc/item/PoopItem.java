package havoc.item;

import net.minecraft.world.item.Item;

public class PoopItem extends Item {
	public PoopItem(Item.Properties properties) {
		super(properties);
	}
}
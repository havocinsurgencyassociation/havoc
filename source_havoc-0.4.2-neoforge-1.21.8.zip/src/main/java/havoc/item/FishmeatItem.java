package havoc.item;

import net.minecraft.world.item.Item;

public class FishmeatItem extends Item {
	public FishmeatItem(Item.Properties properties) {
		super(properties);
	}
}
package havoc.item;

import net.minecraft.world.item.Item;

public class CrimsonScrapItem extends Item {
	public CrimsonScrapItem(Item.Properties properties) {
		super(properties);
	}
}
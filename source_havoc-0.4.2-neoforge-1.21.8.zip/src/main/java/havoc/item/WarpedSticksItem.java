package havoc.item;

import net.minecraft.world.item.Item;

public class WarpedSticksItem extends Item {
	public WarpedSticksItem(Item.Properties properties) {
		super(properties);
	}
}
package havoc.item;

import net.minecraft.world.item.Item;

public class BirchSticksItem extends Item {
	public BirchSticksItem(Item.Properties properties) {
		super(properties);
	}
}
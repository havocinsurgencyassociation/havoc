package havoc.item;

import net.minecraft.world.item.Item;

public class CherryScrapItem extends Item {
	public CherryScrapItem(Item.Properties properties) {
		super(properties);
	}
}
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import havoc.potion.HungryMobEffect;

import havoc.HavocMod;

public class HavocModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, HavocMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> HUNGRY = REGISTRY.register("hungry", () -> new HungryMobEffect());
}
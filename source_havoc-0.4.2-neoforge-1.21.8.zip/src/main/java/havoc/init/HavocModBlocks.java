/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import java.util.function.Function;

import havoc.block.ScrapPlanksOldBlock;
import havoc.block.ScrapPlanksBlock;
import havoc.block.BloodywoolBlock;

import havoc.HavocMod;

public class HavocModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(HavocMod.MODID);
	public static final DeferredBlock<Block> SCRAP_PLANKS;
	public static final DeferredBlock<Block> SCRAP_PLANKS_OLD;
	public static final DeferredBlock<Block> BLOODYWOOL;
	static {
		SCRAP_PLANKS = register("scrap_planks", ScrapPlanksBlock::new);
		SCRAP_PLANKS_OLD = register("scrap_planks_old", ScrapPlanksOldBlock::new);
		BLOODYWOOL = register("bloodywool", BloodywoolBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}
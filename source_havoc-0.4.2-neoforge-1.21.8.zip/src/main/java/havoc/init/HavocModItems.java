/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import java.util.function.Function;

import havoc.item.*;

import havoc.HavocMod;

public class HavocModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(HavocMod.MODID);
	public static final DeferredItem<Item> DEV_PICKAXE;
	public static final DeferredItem<Item> POOP;
	public static final DeferredItem<Item> OAKSCRAP;
	public static final DeferredItem<Item> SPRUCE_SCRAP;
	public static final DeferredItem<Item> BIRCH_SCRAP;
	public static final DeferredItem<Item> JUNGLE_SCRAP;
	public static final DeferredItem<Item> ACACIA_SCRAP;
	public static final DeferredItem<Item> DARKOAK_SCRAP;
	public static final DeferredItem<Item> MANGROVE_SCRAP;
	public static final DeferredItem<Item> CHERRY_SCRAP;
	public static final DeferredItem<Item> CRIMSON_SCRAP;
	public static final DeferredItem<Item> WARPED_SCRAP;
	public static final DeferredItem<Item> MIXED_SCRAP;
	public static final DeferredItem<Item> SCRAP_PLANKS;
	public static final DeferredItem<Item> SCRAP_PLANKS_OLD;
	public static final DeferredItem<Item> BIRCH_STICKS;
	public static final DeferredItem<Item> MANGROVE_STICKS;
	public static final DeferredItem<Item> CHERRY_STICKS;
	public static final DeferredItem<Item> WARPED_STICKS;
	public static final DeferredItem<Item> CRIMSON_STICKS;
	public static final DeferredItem<Item> DEV_TOOL;
	public static final DeferredItem<Item> POOP_SWORD;
	public static final DeferredItem<Item> STRIPPED_BAMBO;
	public static final DeferredItem<Item> BAMBOO_AXE;
	public static final DeferredItem<Item> FLINT_SHEAR;
	public static final DeferredItem<Item> IRON_HAMMER;
	public static final DeferredItem<Item> IRON_SAW;
	public static final DeferredItem<Item> PLANT_STRING;
	public static final DeferredItem<Item> ROPE;
	public static final DeferredItem<Item> BAMBOO_SCRAP;
	public static final DeferredItem<Item> COPPER_NUGGET;
	public static final DeferredItem<Item> COPPER_ARMOR_HELMET;
	public static final DeferredItem<Item> COPPER_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> COPPER_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> COPPER_ARMOR_BOOTS;
	public static final DeferredItem<Item> BRAININFECTED;
	public static final DeferredItem<Item> TESTAXE;
	public static final DeferredItem<Item> ZOMBIEFLESHARMOR_HELMET;
	public static final DeferredItem<Item> ZOMBIEFLESHARMOR_CHESTPLATE;
	public static final DeferredItem<Item> ZOMBIEFLESHARMOR_LEGGINGS;
	public static final DeferredItem<Item> ZOMBIEFLESHARMOR_BOOTS;
	public static final DeferredItem<Item> BURNTBONES;
	public static final DeferredItem<Item> BURNTMEAT;
	public static final DeferredItem<Item> ASH;
	public static final DeferredItem<Item> BLOODYWOOL;
	public static final DeferredItem<Item> FISHMEAT;
	static {
		DEV_PICKAXE = register("dev_pickaxe", DevPickaxeItem::new);
		POOP = register("poop", PoopItem::new);
		OAKSCRAP = register("oakscrap", OakscrapItem::new);
		SPRUCE_SCRAP = register("spruce_scrap", SpruceScrapItem::new);
		BIRCH_SCRAP = register("birch_scrap", BirchScrapItem::new);
		JUNGLE_SCRAP = register("jungle_scrap", JungleScrapItem::new);
		ACACIA_SCRAP = register("acacia_scrap", AcaciaScrapItem::new);
		DARKOAK_SCRAP = register("darkoak_scrap", DarkoakScrapItem::new);
		MANGROVE_SCRAP = register("mangrove_scrap", MangroveScrapItem::new);
		CHERRY_SCRAP = register("cherry_scrap", CherryScrapItem::new);
		CRIMSON_SCRAP = register("crimson_scrap", CrimsonScrapItem::new);
		WARPED_SCRAP = register("warped_scrap", WarpedScrapItem::new);
		MIXED_SCRAP = register("mixed_scrap", MixedScrapItem::new);
		SCRAP_PLANKS = block(HavocModBlocks.SCRAP_PLANKS);
		SCRAP_PLANKS_OLD = block(HavocModBlocks.SCRAP_PLANKS_OLD);
		BIRCH_STICKS = register("birch_sticks", BirchSticksItem::new);
		MANGROVE_STICKS = register("mangrove_sticks", MangroveSticksItem::new);
		CHERRY_STICKS = register("cherry_sticks", CherrySticksItem::new);
		WARPED_STICKS = register("warped_sticks", WarpedSticksItem::new);
		CRIMSON_STICKS = register("crimson_sticks", CrimsonSticksItem::new);
		DEV_TOOL = register("dev_tool", DevToolItem::new);
		POOP_SWORD = register("poop_sword", PoopSwordItem::new);
		STRIPPED_BAMBO = register("stripped_bambo", StrippedBamboItem::new);
		BAMBOO_AXE = register("bamboo_axe", BambooAxeItem::new);
		FLINT_SHEAR = register("flint_shear", FlintShearItem::new);
		IRON_HAMMER = register("iron_hammer", IronHammerItem::new);
		IRON_SAW = register("iron_saw", IronSawItem::new);
		PLANT_STRING = register("plant_string", PlantStringItem::new);
		ROPE = register("rope", RopeItem::new);
		BAMBOO_SCRAP = register("bamboo_scrap", BambooScrapItem::new);
		COPPER_NUGGET = register("copper_nugget", CopperNuggetItem::new);
		COPPER_ARMOR_HELMET = register("copper_armor_helmet", CopperArmorItem.Helmet::new);
		COPPER_ARMOR_CHESTPLATE = register("copper_armor_chestplate", CopperArmorItem.Chestplate::new);
		COPPER_ARMOR_LEGGINGS = register("copper_armor_leggings", CopperArmorItem.Leggings::new);
		COPPER_ARMOR_BOOTS = register("copper_armor_boots", CopperArmorItem.Boots::new);
		BRAININFECTED = register("braininfected", BraininfectedItem::new);
		TESTAXE = register("testaxe", TestaxeItem::new);
		ZOMBIEFLESHARMOR_HELMET = register("zombieflesharmor_helmet", ZombieflesharmorItem.Helmet::new);
		ZOMBIEFLESHARMOR_CHESTPLATE = register("zombieflesharmor_chestplate", ZombieflesharmorItem.Chestplate::new);
		ZOMBIEFLESHARMOR_LEGGINGS = register("zombieflesharmor_leggings", ZombieflesharmorItem.Leggings::new);
		ZOMBIEFLESHARMOR_BOOTS = register("zombieflesharmor_boots", ZombieflesharmorItem.Boots::new);
		BURNTBONES = register("burntbones", BurntbonesItem::new);
		BURNTMEAT = register("burntmeat", BurntmeatItem::new);
		ASH = register("ash", AshItem::new);
		BLOODYWOOL = block(HavocModBlocks.BLOODYWOOL);
		FISHMEAT = register("fishmeat", FishmeatItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import havoc.HavocMod;

@EventBusSubscriber
public class HavocModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, HavocMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> SCRAPSANDROCKS = REGISTRY.register("scrapsandrocks",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.havoc.scrapsandrocks")).icon(() -> new ItemStack(HavocModItems.OAKSCRAP.get())).displayItems((parameters, tabData) -> {
				tabData.accept(HavocModItems.DEV_PICKAXE.get());
				tabData.accept(HavocModItems.POOP.get());
				tabData.accept(HavocModItems.OAKSCRAP.get());
				tabData.accept(HavocModItems.SPRUCE_SCRAP.get());
				tabData.accept(HavocModItems.BIRCH_SCRAP.get());
				tabData.accept(HavocModItems.JUNGLE_SCRAP.get());
				tabData.accept(HavocModItems.ACACIA_SCRAP.get());
				tabData.accept(HavocModItems.DARKOAK_SCRAP.get());
				tabData.accept(HavocModItems.MANGROVE_SCRAP.get());
				tabData.accept(HavocModItems.CHERRY_SCRAP.get());
				tabData.accept(HavocModItems.CRIMSON_SCRAP.get());
				tabData.accept(HavocModItems.WARPED_SCRAP.get());
				tabData.accept(HavocModItems.MIXED_SCRAP.get());
				tabData.accept(HavocModBlocks.SCRAP_PLANKS.get().asItem());
				tabData.accept(HavocModBlocks.SCRAP_PLANKS_OLD.get().asItem());
				tabData.accept(HavocModItems.BIRCH_STICKS.get());
				tabData.accept(HavocModItems.MANGROVE_STICKS.get());
				tabData.accept(HavocModItems.CHERRY_STICKS.get());
				tabData.accept(HavocModItems.WARPED_STICKS.get());
				tabData.accept(HavocModItems.CRIMSON_STICKS.get());
				tabData.accept(HavocModItems.DEV_TOOL.get());
				tabData.accept(HavocModItems.POOP_SWORD.get());
				tabData.accept(HavocModItems.FLINT_SHEAR.get());
				tabData.accept(HavocModItems.IRON_HAMMER.get());
				tabData.accept(HavocModItems.IRON_SAW.get());
				tabData.accept(HavocModItems.PLANT_STRING.get());
				tabData.accept(HavocModItems.COPPER_NUGGET.get());
				tabData.accept(HavocModItems.COPPER_ARMOR_HELMET.get());
				tabData.accept(HavocModItems.COPPER_ARMOR_CHESTPLATE.get());
				tabData.accept(HavocModItems.COPPER_ARMOR_LEGGINGS.get());
				tabData.accept(HavocModItems.COPPER_ARMOR_BOOTS.get());
				tabData.accept(HavocModItems.BRAININFECTED.get());
				tabData.accept(HavocModItems.TESTAXE.get());
				tabData.accept(HavocModItems.ZOMBIEFLESHARMOR_HELMET.get());
				tabData.accept(HavocModItems.ZOMBIEFLESHARMOR_CHESTPLATE.get());
				tabData.accept(HavocModItems.ZOMBIEFLESHARMOR_LEGGINGS.get());
				tabData.accept(HavocModItems.ZOMBIEFLESHARMOR_BOOTS.get());
				tabData.accept(HavocModItems.BURNTBONES.get());
				tabData.accept(HavocModItems.FISHMEAT.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(HavocModItems.OAKSCRAP.get());
			tabData.accept(HavocModItems.SPRUCE_SCRAP.get());
			tabData.accept(HavocModItems.BIRCH_SCRAP.get());
			tabData.accept(HavocModItems.JUNGLE_SCRAP.get());
			tabData.accept(HavocModItems.ACACIA_SCRAP.get());
			tabData.accept(HavocModItems.DARKOAK_SCRAP.get());
			tabData.accept(HavocModItems.MANGROVE_SCRAP.get());
			tabData.accept(HavocModItems.CHERRY_SCRAP.get());
			tabData.accept(HavocModItems.CRIMSON_SCRAP.get());
			tabData.accept(HavocModItems.WARPED_SCRAP.get());
			tabData.accept(HavocModItems.MIXED_SCRAP.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(HavocModBlocks.SCRAP_PLANKS.get().asItem());
			tabData.accept(HavocModBlocks.SCRAP_PLANKS_OLD.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(HavocModItems.BAMBOO_AXE.get());
			tabData.accept(HavocModItems.FLINT_SHEAR.get());
			tabData.accept(HavocModItems.IRON_HAMMER.get());
			tabData.accept(HavocModItems.IRON_SAW.get());
		}
	}
}
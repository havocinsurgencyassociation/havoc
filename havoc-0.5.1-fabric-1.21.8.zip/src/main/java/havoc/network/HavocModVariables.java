package havoc.network;

public class HavocModVariables {
	public static double havoc_tick = 0;

	public static void variablesLoad() {
	}
}
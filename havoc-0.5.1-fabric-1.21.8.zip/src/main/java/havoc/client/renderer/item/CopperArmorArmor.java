package havoc.client.renderer.item;

import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.resources.model.EquipmentClientInfo;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import havoc.init.HavocModItems;
import havoc.init.HavocModArmorModels;

@Environment(EnvType.CLIENT)
public class CopperArmorArmor {
	public static void clientLoad() {
		HavocModArmorModels.ARMOR_MODELS.put(HavocModItems.COPPER_ARMOR_HELMET, new HavocModArmorModels.ArmorModel() {
			private final ResourceLocation armorTexture = ResourceLocation.parse("havoc:textures/models/armor/test_layer_1.png");

			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation original) {
				return armorTexture;
			}
		});
		HavocModArmorModels.ARMOR_MODELS.put(HavocModItems.COPPER_ARMOR_CHESTPLATE, new HavocModArmorModels.ArmorModel() {
			private final ResourceLocation armorTexture = ResourceLocation.parse("havoc:textures/models/armor/test_layer_1.png");

			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation original) {
				return armorTexture;
			}
		});
		HavocModArmorModels.ARMOR_MODELS.put(HavocModItems.COPPER_ARMOR_LEGGINGS, new HavocModArmorModels.ArmorModel() {
			private final ResourceLocation armorTexture = ResourceLocation.parse("havoc:textures/models/armor/test_layer_2.png");

			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation original) {
				return armorTexture;
			}
		});
		HavocModArmorModels.ARMOR_MODELS.put(HavocModItems.COPPER_ARMOR_BOOTS, new HavocModArmorModels.ArmorModel() {
			private final ResourceLocation armorTexture = ResourceLocation.parse("havoc:textures/models/armor/test_layer_1.png");

			@Override
			public ResourceLocation getArmorTexture(ItemStack stack, EquipmentClientInfo.LayerType type, EquipmentClientInfo.Layer layer, ResourceLocation original) {
				return armorTexture;
			}
		});
	}
}
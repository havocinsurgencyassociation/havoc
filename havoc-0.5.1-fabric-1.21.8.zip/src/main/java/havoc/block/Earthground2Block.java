package havoc.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;

import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;

import java.util.function.Predicate;

public class Earthground2Block extends Block {
	public Earthground2Block(BlockBehaviour.Properties properties) {
		super(properties.sound(new SoundType(1.0f, 1.0f, null, null, null, null, null) {
			@Override
			public SoundEvent getBreakSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.underwater.enter"));
			}

			@Override
			public SoundEvent getStepSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.underwater.enter"));
			}

			@Override
			public SoundEvent getPlaceSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.underwater.enter"));
			}

			@Override
			public SoundEvent getHitSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.underwater.enter"));
			}

			@Override
			public SoundEvent getFallSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.underwater.enter"));
			}
		}).strength(-1, 3600000).lightLevel(blockstate -> 15).noCollission().hasPostProcess((bs, br, bp) -> true).emissiveRendering((bs, br, bp) -> true));
	}

	public static final Predicate<BiomeSelectionContext> GENERATE_BIOMES = BiomeSelectors.includeByKey(ResourceKey.create(Registries.BIOME, ResourceLocation.parse("havoc:spaceempty")));

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}
package havoc.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

public class BloodywoolBlock extends Block {
	public BloodywoolBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(new SoundType(1.0f, 1.0f, null, null, null, null, null) {
			@Override
			public SoundEvent getBreakSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wool.break"));
			}

			@Override
			public SoundEvent getStepSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.slime_block.step"));
			}

			@Override
			public SoundEvent getPlaceSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("entity.slime.squish"));
			}

			@Override
			public SoundEvent getHitSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wool.hit"));
			}

			@Override
			public SoundEvent getFallSound() {
				return BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("block.wool.fall"));
			}
		}).strength(1f, 10f));
	}
}
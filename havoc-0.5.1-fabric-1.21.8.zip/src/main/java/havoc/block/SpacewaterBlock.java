package havoc.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.LiquidBlock;

import havoc.init.HavocModFluids;

public class SpacewaterBlock extends LiquidBlock {
	public SpacewaterBlock(BlockBehaviour.Properties properties) {
		super(HavocModFluids.SPACEWATER, properties.mapColor(MapColor.WATER).strength(100f).noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
	}
}
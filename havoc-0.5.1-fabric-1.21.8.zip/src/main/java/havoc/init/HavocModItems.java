/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BoatItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import java.util.function.Function;

import havoc.item.*;

import havoc.HavocMod;

public class HavocModItems {
	public static Item DEV_PICKAXE;
	public static Item POOP;
	public static Item OAKSCRAP;
	public static Item SPRUCE_SCRAP;
	public static Item BIRCH_SCRAP;
	public static Item JUNGLE_SCRAP;
	public static Item ACACIA_SCRAP;
	public static Item DARKOAK_SCRAP;
	public static Item MANGROVE_SCRAP;
	public static Item CHERRY_SCRAP;
	public static Item CRIMSON_SCRAP;
	public static Item WARPED_SCRAP;
	public static Item MIXED_SCRAP;
	public static Item SCRAP_PLANKS;
	public static Item SCRAP_PLANKS_OLD;
	public static Item BIRCH_STICKS;
	public static Item MANGROVE_STICKS;
	public static Item CHERRY_STICKS;
	public static Item WARPED_STICKS;
	public static Item CRIMSON_STICKS;
	public static Item DEV_TOOL;
	public static Item POOP_SWORD;
	public static Item STRIPPED_BAMBO;
	public static Item BAMBOO_AXE;
	public static Item FLINT_SHEAR;
	public static Item IRON_HAMMER;
	public static Item IRON_SAW;
	public static Item PLANT_STRING;
	public static Item ROPE;
	public static Item BAMBOO_SCRAP;
	public static Item COPPER_NUGGET;
	public static Item COPPER_ARMOR_HELMET;
	public static Item COPPER_ARMOR_CHESTPLATE;
	public static Item COPPER_ARMOR_LEGGINGS;
	public static Item COPPER_ARMOR_BOOTS;
	public static Item BRAININFECTED;
	public static Item TESTAXE;
	public static Item ZOMBIEFLESHARMOR_HELMET;
	public static Item ZOMBIEFLESHARMOR_CHESTPLATE;
	public static Item ZOMBIEFLESHARMOR_LEGGINGS;
	public static Item ZOMBIEFLESHARMOR_BOOTS;
	public static Item BURNTBONES;
	public static Item BURNTMEAT;
	public static Item ASH;
	public static Item BLOODYWOOL;
	public static Item FISHMEAT;
	public static Item SOFTBEDROCK;
	public static Item VACUM;
	public static Item EARTHWATER;
	public static Item EARTHGROUND;
	public static Item EARTHGROUND_2;
	public static Item EARTHGROUND_3;
	public static Item SPACEWATER_BUCKET;
	public static Item BUILDINGHELPER;
	public static Item APPLE;
	public static Item GOLDEN_APPLE;
	public static Item ENCHANTED_GOLDEN_APPLE;
	public static Item MELON_SLICE;
	public static Item SWEAT_BERRIES;
	public static Item GLOW_BERRIES;
	public static Item CHORUS_FRUIT;
	public static Item CARROT;
	public static Item GOLDEN_CARROT;
	public static Item OBSIDIANBOAT;

	public static void load() {
		DEV_PICKAXE = register("dev_pickaxe", DevPickaxeItem::new);
		POOP = register("poop", PoopItem::new);
		OAKSCRAP = register("oakscrap", OakscrapItem::new);
		SPRUCE_SCRAP = register("spruce_scrap", SpruceScrapItem::new);
		BIRCH_SCRAP = register("birch_scrap", BirchScrapItem::new);
		JUNGLE_SCRAP = register("jungle_scrap", JungleScrapItem::new);
		ACACIA_SCRAP = register("acacia_scrap", AcaciaScrapItem::new);
		DARKOAK_SCRAP = register("darkoak_scrap", DarkoakScrapItem::new);
		MANGROVE_SCRAP = register("mangrove_scrap", MangroveScrapItem::new);
		CHERRY_SCRAP = register("cherry_scrap", CherryScrapItem::new);
		CRIMSON_SCRAP = register("crimson_scrap", CrimsonScrapItem::new);
		WARPED_SCRAP = register("warped_scrap", WarpedScrapItem::new);
		MIXED_SCRAP = register("mixed_scrap", MixedScrapItem::new);
		SCRAP_PLANKS = block(HavocModBlocks.SCRAP_PLANKS, "scrap_planks");
		SCRAP_PLANKS_OLD = block(HavocModBlocks.SCRAP_PLANKS_OLD, "scrap_planks_old");
		BIRCH_STICKS = register("birch_sticks", BirchSticksItem::new);
		MANGROVE_STICKS = register("mangrove_sticks", MangroveSticksItem::new);
		CHERRY_STICKS = register("cherry_sticks", CherrySticksItem::new);
		WARPED_STICKS = register("warped_sticks", WarpedSticksItem::new);
		CRIMSON_STICKS = register("crimson_sticks", CrimsonSticksItem::new);
		DEV_TOOL = register("dev_tool", DevToolItem::new);
		POOP_SWORD = register("poop_sword", PoopSwordItem::new);
		STRIPPED_BAMBO = register("stripped_bambo", StrippedBamboItem::new);
		BAMBOO_AXE = register("bamboo_axe", BambooAxeItem::new);
		FLINT_SHEAR = register("flint_shear", FlintShearItem::new);
		IRON_HAMMER = register("iron_hammer", IronHammerItem::new);
		IRON_SAW = register("iron_saw", IronSawItem::new);
		PLANT_STRING = register("plant_string", PlantStringItem::new);
		ROPE = register("rope", RopeItem::new);
		BAMBOO_SCRAP = register("bamboo_scrap", BambooScrapItem::new);
		COPPER_NUGGET = register("copper_nugget", CopperNuggetItem::new);
		COPPER_ARMOR_HELMET = register("copper_armor_helmet", CopperArmorItem.Helmet::new);
		COPPER_ARMOR_CHESTPLATE = register("copper_armor_chestplate", CopperArmorItem.Chestplate::new);
		COPPER_ARMOR_LEGGINGS = register("copper_armor_leggings", CopperArmorItem.Leggings::new);
		COPPER_ARMOR_BOOTS = register("copper_armor_boots", CopperArmorItem.Boots::new);
		BRAININFECTED = register("braininfected", BraininfectedItem::new);
		TESTAXE = register("testaxe", TestaxeItem::new);
		ZOMBIEFLESHARMOR_HELMET = register("zombieflesharmor_helmet", ZombieflesharmorItem.Helmet::new);
		ZOMBIEFLESHARMOR_CHESTPLATE = register("zombieflesharmor_chestplate", ZombieflesharmorItem.Chestplate::new);
		ZOMBIEFLESHARMOR_LEGGINGS = register("zombieflesharmor_leggings", ZombieflesharmorItem.Leggings::new);
		ZOMBIEFLESHARMOR_BOOTS = register("zombieflesharmor_boots", ZombieflesharmorItem.Boots::new);
		BURNTBONES = register("burntbones", BurntbonesItem::new);
		BURNTMEAT = register("burntmeat", BurntmeatItem::new);
		ASH = register("ash", AshItem::new);
		BLOODYWOOL = block(HavocModBlocks.BLOODYWOOL, "bloodywool");
		FISHMEAT = register("fishmeat", FishmeatItem::new);
		SOFTBEDROCK = block(HavocModBlocks.SOFTBEDROCK, "softbedrock", new Item.Properties().rarity(Rarity.EPIC).fireResistant());
		VACUM = block(HavocModBlocks.VACUM, "vacum", new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
		EARTHWATER = block(HavocModBlocks.EARTHWATER, "earthwater", new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
		EARTHGROUND = block(HavocModBlocks.EARTHGROUND, "earthground", new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
		EARTHGROUND_2 = block(HavocModBlocks.EARTHGROUND_2, "earthground_2", new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
		EARTHGROUND_3 = block(HavocModBlocks.EARTHGROUND_3, "earthground_3", new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant());
		SPACEWATER_BUCKET = register("spacewater_bucket", SpacewaterItem::new);
		BUILDINGHELPER = block(HavocModBlocks.BUILDINGHELPER, "buildinghelper", new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
		APPLE = register("apple", AppleItem::new);
		GOLDEN_APPLE = register("golden_apple", GoldenAppleItem::new);
		ENCHANTED_GOLDEN_APPLE = register("enchanted_golden_apple", EnchantedGoldenAppleItem::new);
		MELON_SLICE = register("melon_slice", MelonSliceItem::new);
		SWEAT_BERRIES = register("sweat_berries", SweatBerriesItem::new);
		GLOW_BERRIES = register("glow_berries", GlowBerriesItem::new);
		CHORUS_FRUIT = register("chorus_fruit", ChorusFruitItem::new);
		CARROT = register("carrot", CarrotItem::new);
		GOLDEN_CARROT = register("golden_carrot", GoldenCarrotItem::new);
		OBSIDIANBOAT = register("obsidianboat", properties -> new BoatItem(HavocModEntities.OBSIDIANBOAT, properties.stacksTo(1)));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> I register(String name, Function<Item.Properties, ? extends I> supplier) {
		return (I) Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(HavocMod.MODID, name)), (Function<Item.Properties, Item>) supplier);
	}

	private static Item block(Block block, String name) {
		return block(block, name, new Item.Properties());
	}

	private static Item block(Block block, String name, Item.Properties properties) {
		return Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(HavocMod.MODID, name)), prop -> new BlockItem(block, prop), properties);
	}
}
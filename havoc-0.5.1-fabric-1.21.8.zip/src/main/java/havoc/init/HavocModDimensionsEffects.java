/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import havoc.client.dimension.SpaceDimensionEffects;

@Environment(EnvType.CLIENT)
public class HavocModDimensionsEffects {
	public static void clientLoad() {
		SpaceDimensionEffects.clientLoad();
	}
}
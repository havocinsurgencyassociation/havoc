/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.BoatModel;

import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class HavocModModels {
	public static final ModelLayerLocation OBSIDIANBOAT_LAYER_LOCATION = new ModelLayerLocation(ResourceLocation.parse("havoc:boat/obsidianboat"), "main");

	public static void clientLoad() {
		EntityModelLayerRegistry.registerModelLayer(OBSIDIANBOAT_LAYER_LOCATION, BoatModel::createBoatModel);
	}
}
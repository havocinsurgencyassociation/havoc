/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import havoc.procedures.*;

@SuppressWarnings("InstantiationOfUtilityClass")
public class HavocModProcedures {
	public static void load() {
		new ZombiedropProcedure();
		new GamerulechangesProcedure();
		new RespawnnegativesProcedure();
		new ExperiencebonusesProcedure();
		new AllxpdroppedProcedure();
		new HungerlevelsProcedure();
		new GamerulesonworldloadupProcedure();
		new SkeletonmodProcedure();
		new Droparmornitems100Procedure();
		new AnimalmeatoverrideProcedure();
		new MiscdropoverrideProcedure();
		new EndermendropProcedure();
		new JoinnegativesProcedure();
		new XphealProcedure();
		new ExpdropsfrommobsProcedure();
		new ArmorweightProcedure();
		new VillageronspawnoverrideProcedure();
		new VoidspawnProcedure();
		new FixspaceblocksProcedure();
		new BedbreakerclientProcedure();
		new FoodreplacerProcedure();
		new GlobalticktimerProcedure();
		new FoodreplaceronpickupProcedure();
		new HealthfromfoodforeignProcedure();
	}
}
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.function.Supplier;

import havoc.fluid.SpacewaterFluid;

import havoc.HavocMod;

public class HavocModFluids {
	public static FlowingFluid SPACEWATER;
	public static FlowingFluid FLOWING_SPACEWATER;

	public static void load() {
		SPACEWATER = register("spacewater", SpacewaterFluid.Source::new);
		FLOWING_SPACEWATER = register("flowing_spacewater", SpacewaterFluid.Flowing::new);
	}

	@Environment(EnvType.CLIENT)
	public static void clientLoad() {
		SpacewaterFluid.clientLoad();
	}

	private static <F extends Fluid> F register(String registryname, Supplier<F> element) {
		return (F) Registry.register(BuiltInRegistries.FLUID, ResourceLocation.fromNamespaceAndPath(HavocMod.MODID, registryname), element.get());
	}
}
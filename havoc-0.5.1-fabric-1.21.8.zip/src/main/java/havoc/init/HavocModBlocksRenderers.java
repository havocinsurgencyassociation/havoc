/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import havoc.fluid.SpacewaterFluid;

import havoc.block.VacumBlock;
import havoc.block.ScrapPlanksOldBlock;
import havoc.block.BuildinghelperBlock;

@Environment(EnvType.CLIENT)
public class HavocModBlocksRenderers {
	public static void clientLoad() {
		ScrapPlanksOldBlock.registerRenderLayer();
		VacumBlock.registerRenderLayer();
		SpacewaterFluid.registerRenderLayer();
		BuildinghelperBlock.registerRenderLayer();
	}
	// Start of user code block custom block renderers
	// End of user code block custom block renderers
}
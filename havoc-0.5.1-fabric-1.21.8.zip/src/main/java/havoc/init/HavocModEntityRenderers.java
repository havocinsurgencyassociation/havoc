/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.minecraft.client.renderer.entity.BoatRenderer;

import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class HavocModEntityRenderers {
	public static void clientLoad() {
		EntityRendererRegistry.register(HavocModEntities.OBSIDIANBOAT, context -> new BoatRenderer(context, HavocModModels.OBSIDIANBOAT_LAYER_LOCATION));
	}
}
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;
import net.minecraft.world.level.levelgen.feature.OreFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;

import java.util.function.Predicate;

import havoc.block.SoftbedrockBlock;
import havoc.block.EarthwaterBlock;
import havoc.block.EarthgroundBlock;
import havoc.block.Earthground3Block;
import havoc.block.Earthground2Block;

import havoc.HavocMod;

public class HavocModFeatures {
	public static void load() {
		register("softbedrock", new OreFeature(OreConfiguration.CODEC), SoftbedrockBlock.GENERATE_BIOMES, GenerationStep.Decoration.UNDERGROUND_ORES);
		register("earthwater", new OreFeature(OreConfiguration.CODEC), EarthwaterBlock.GENERATE_BIOMES, GenerationStep.Decoration.UNDERGROUND_ORES);
		register("earthground", new OreFeature(OreConfiguration.CODEC), EarthgroundBlock.GENERATE_BIOMES, GenerationStep.Decoration.UNDERGROUND_ORES);
		register("earthground_2", new OreFeature(OreConfiguration.CODEC), Earthground2Block.GENERATE_BIOMES, GenerationStep.Decoration.UNDERGROUND_ORES);
		register("earthground_3", new OreFeature(OreConfiguration.CODEC), Earthground3Block.GENERATE_BIOMES, GenerationStep.Decoration.UNDERGROUND_ORES);
	}

	private static void register(String registryname, Feature feature, Predicate<BiomeSelectionContext> biomes, GenerationStep.Decoration stage) {
		register(registryname, feature);
		BiomeModifications.addFeature(biomes, stage, ResourceKey.create(Registries.PLACED_FEATURE, ResourceLocation.fromNamespaceAndPath(HavocMod.MODID, registryname)));
	}

	private static void register(String registryname, Feature feature) {
		Registry.register(BuiltInRegistries.FEATURE, ResourceLocation.fromNamespaceAndPath(HavocMod.MODID, registryname), feature);
	}
}
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.core.dispenser.BoatDispenseItemBehavior;

public class HavocModDispenseBehaviors {
	public static void load() {
		DispenserBlock.registerBehavior(HavocModItems.OBSIDIANBOAT, new BoatDispenseItemBehavior(HavocModEntities.OBSIDIANBOAT));
	}
}
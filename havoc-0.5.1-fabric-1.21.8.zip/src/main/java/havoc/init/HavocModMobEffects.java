/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.core.Holder;

import java.util.function.Supplier;

import havoc.potion.HungryMobEffect;

import havoc.HavocMod;

public class HavocModMobEffects {
	public static Holder<MobEffect> HUNGRY;

	public static void load() {
		HUNGRY = register("hungry", HungryMobEffect::new);
	}

	private static Holder<MobEffect> register(String registryname, Supplier<MobEffect> element) {
		return Holder.direct(Registry.register(BuiltInRegistries.MOB_EFFECT, ResourceLocation.fromNamespaceAndPath(HavocMod.MODID, registryname), element.get()));
	}
}
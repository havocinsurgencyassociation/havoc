/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

import havoc.HavocMod;

public class HavocModTabs {
	public static ResourceKey<CreativeModeTab> TAB_SCRAPSANDROCKS = ResourceKey.create(Registries.CREATIVE_MODE_TAB, ResourceLocation.fromNamespaceAndPath(HavocMod.MODID, "scrapsandrocks"));

	public static void load() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_SCRAPSANDROCKS, CreativeModeTab.builder(CreativeModeTab.Row.TOP, 0).title(Component.translatable("item_group.havoc.scrapsandrocks")).icon(() -> new ItemStack(HavocModItems.OAKSCRAP))
				.type(CreativeModeTab.Type.SEARCH).backgroundTexture(ResourceLocation.withDefaultNamespace("textures/gui/container/creative_inventory/tab_item_search.png")).displayItems((parameters, tabData) -> {
					tabData.accept(HavocModItems.DEV_PICKAXE);
					tabData.accept(HavocModItems.POOP);
					tabData.accept(HavocModItems.OAKSCRAP);
					tabData.accept(HavocModItems.SPRUCE_SCRAP);
					tabData.accept(HavocModItems.BIRCH_SCRAP);
					tabData.accept(HavocModItems.JUNGLE_SCRAP);
					tabData.accept(HavocModItems.ACACIA_SCRAP);
					tabData.accept(HavocModItems.DARKOAK_SCRAP);
					tabData.accept(HavocModItems.MANGROVE_SCRAP);
					tabData.accept(HavocModItems.CHERRY_SCRAP);
					tabData.accept(HavocModItems.CRIMSON_SCRAP);
					tabData.accept(HavocModItems.WARPED_SCRAP);
					tabData.accept(HavocModItems.MIXED_SCRAP);
					tabData.accept(HavocModBlocks.SCRAP_PLANKS.asItem());
					tabData.accept(HavocModBlocks.SCRAP_PLANKS_OLD.asItem());
					tabData.accept(HavocModItems.BIRCH_STICKS);
					tabData.accept(HavocModItems.MANGROVE_STICKS);
					tabData.accept(HavocModItems.CHERRY_STICKS);
					tabData.accept(HavocModItems.WARPED_STICKS);
					tabData.accept(HavocModItems.CRIMSON_STICKS);
					tabData.accept(HavocModItems.DEV_TOOL);
					tabData.accept(HavocModItems.POOP_SWORD);
					tabData.accept(HavocModItems.FLINT_SHEAR);
					tabData.accept(HavocModItems.IRON_HAMMER);
					tabData.accept(HavocModItems.IRON_SAW);
					tabData.accept(HavocModItems.PLANT_STRING);
					tabData.accept(HavocModItems.COPPER_NUGGET);
					tabData.accept(HavocModItems.COPPER_ARMOR_HELMET);
					tabData.accept(HavocModItems.COPPER_ARMOR_CHESTPLATE);
					tabData.accept(HavocModItems.COPPER_ARMOR_LEGGINGS);
					tabData.accept(HavocModItems.COPPER_ARMOR_BOOTS);
					tabData.accept(HavocModItems.BRAININFECTED);
					tabData.accept(HavocModItems.TESTAXE);
					tabData.accept(HavocModItems.ZOMBIEFLESHARMOR_HELMET);
					tabData.accept(HavocModItems.ZOMBIEFLESHARMOR_CHESTPLATE);
					tabData.accept(HavocModItems.ZOMBIEFLESHARMOR_LEGGINGS);
					tabData.accept(HavocModItems.ZOMBIEFLESHARMOR_BOOTS);
					tabData.accept(HavocModItems.BURNTBONES);
					tabData.accept(HavocModItems.FISHMEAT);
					tabData.accept(HavocModBlocks.SOFTBEDROCK.asItem());
					tabData.accept(HavocModBlocks.VACUM.asItem());
					tabData.accept(HavocModBlocks.EARTHWATER.asItem());
					tabData.accept(HavocModBlocks.EARTHGROUND.asItem());
					tabData.accept(HavocModBlocks.EARTHGROUND_2.asItem());
					tabData.accept(HavocModBlocks.EARTHGROUND_3.asItem());
					tabData.accept(HavocModItems.SPACEWATER_BUCKET);
					tabData.accept(HavocModBlocks.BUILDINGHELPER.asItem());
					tabData.accept(HavocModItems.APPLE);
					tabData.accept(HavocModItems.GOLDEN_APPLE);
					tabData.accept(HavocModItems.ENCHANTED_GOLDEN_APPLE);
					tabData.accept(HavocModItems.MELON_SLICE);
					tabData.accept(HavocModItems.SWEAT_BERRIES);
					tabData.accept(HavocModItems.GLOW_BERRIES);
					tabData.accept(HavocModItems.CHORUS_FRUIT);
					tabData.accept(HavocModItems.CARROT);
					tabData.accept(HavocModItems.GOLDEN_CARROT);
					tabData.accept(HavocModItems.OBSIDIANBOAT);
				}).build());
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(tabData -> {
			tabData.accept(HavocModItems.OAKSCRAP);
			tabData.accept(HavocModItems.SPRUCE_SCRAP);
			tabData.accept(HavocModItems.BIRCH_SCRAP);
			tabData.accept(HavocModItems.JUNGLE_SCRAP);
			tabData.accept(HavocModItems.ACACIA_SCRAP);
			tabData.accept(HavocModItems.DARKOAK_SCRAP);
			tabData.accept(HavocModItems.MANGROVE_SCRAP);
			tabData.accept(HavocModItems.CHERRY_SCRAP);
			tabData.accept(HavocModItems.CRIMSON_SCRAP);
			tabData.accept(HavocModItems.WARPED_SCRAP);
			tabData.accept(HavocModItems.MIXED_SCRAP);
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.BUILDING_BLOCKS).register(tabData -> {
			tabData.accept(HavocModBlocks.SCRAP_PLANKS.asItem());
			tabData.accept(HavocModBlocks.SCRAP_PLANKS_OLD.asItem());
		});
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(tabData -> {
			tabData.accept(HavocModItems.BAMBOO_AXE);
			tabData.accept(HavocModItems.FLINT_SHEAR);
			tabData.accept(HavocModItems.IRON_HAMMER);
			tabData.accept(HavocModItems.IRON_SAW);
		});
	}
}
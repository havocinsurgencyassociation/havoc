/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package havoc.init;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import java.util.function.Function;

import havoc.block.*;

import havoc.HavocMod;

public class HavocModBlocks {
	public static Block SCRAP_PLANKS;
	public static Block SCRAP_PLANKS_OLD;
	public static Block BLOODYWOOL;
	public static Block SOFTBEDROCK;
	public static Block VACUM;
	public static Block EARTHWATER;
	public static Block EARTHGROUND;
	public static Block EARTHGROUND_2;
	public static Block EARTHGROUND_3;
	public static Block SPACEWATER;
	public static Block BUILDINGHELPER;

	public static void load() {
		SCRAP_PLANKS = register("scrap_planks", ScrapPlanksBlock::new);
		SCRAP_PLANKS_OLD = register("scrap_planks_old", ScrapPlanksOldBlock::new);
		BLOODYWOOL = register("bloodywool", BloodywoolBlock::new);
		SOFTBEDROCK = register("softbedrock", SoftbedrockBlock::new);
		VACUM = register("vacum", VacumBlock::new);
		EARTHWATER = register("earthwater", EarthwaterBlock::new);
		EARTHGROUND = register("earthground", EarthgroundBlock::new);
		EARTHGROUND_2 = register("earthground_2", Earthground2Block::new);
		EARTHGROUND_3 = register("earthground_3", Earthground3Block::new);
		SPACEWATER = register("spacewater", SpacewaterBlock::new);
		BUILDINGHELPER = register("buildinghelper", BuildinghelperBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> B register(String name, Function<BlockBehaviour.Properties, B> supplier) {
		return (B) Blocks.register(ResourceKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath(HavocMod.MODID, name)), (Function<BlockBehaviour.Properties, Block>) supplier, BlockBehaviour.Properties.of());
	}
}
package havoc.entity;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.entity.EntityType;

import havoc.init.HavocModItems;

public class ObsidianboatEntity extends Boat {
	public ObsidianboatEntity(EntityType<ObsidianboatEntity> type, Level world) {
		super(type, world, () -> HavocModItems.OBSIDIANBOAT);
	}
}
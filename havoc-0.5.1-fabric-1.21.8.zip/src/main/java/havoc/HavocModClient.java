package havoc;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.ClientModInitializer;

import havoc.init.*;

@Environment(EnvType.CLIENT)
public class HavocModClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Start of user code block mod constructor
		// End of user code block mod constructor
		HavocModModels.clientLoad();
		HavocModBlocksRenderers.clientLoad();
		HavocModArmorModels.clientLoad();
		HavocModEntityRenderers.clientLoad();
		HavocModFluids.clientLoad();
		HavocModDimensionsEffects.clientLoad();
		HavocModScreens.clientLoad();
		HavocModMenus.clientLoad();
		// Start of user code block mod init
		// End of user code block mod init
	}
	// Start of user code block mod methods
	// End of user code block mod methods
}
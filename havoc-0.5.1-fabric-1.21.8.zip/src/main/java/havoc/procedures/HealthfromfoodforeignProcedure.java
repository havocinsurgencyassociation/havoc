package havoc.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.Difficulty;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import havoc.event.LivingEntityEvents;

public class HealthfromfoodforeignProcedure {
	public static boolean eventResult = true;

	public HealthfromfoodforeignProcedure() {
		LivingEntityEvents.START_USE_ITEM.register((entity, itemstack) -> {
			execute(entity.level(), entity, itemstack);
		});
	}

	public static void execute(LevelAccessor world, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		double food_num = 0;
		if (!(BuiltInRegistries.ITEM.getKey(itemstack.getItem()).toString()).startsWith("havoc") && !(Items.CHORUS_FRUIT == itemstack.getItem())) {
			if (itemstack.has(DataComponents.FOOD)) {
				if (entity instanceof Player _player) {
					_player.getFoodData().setSaturation(20);
				}
				if (entity instanceof Player _player) {
					_player.getFoodData().setFoodLevel(19);
				}
				if (world.getDifficulty() == Difficulty.HARD) {
					if (entity instanceof Player _player) {
						_player.getCooldowns().addCooldown(itemstack, 80);
					}
				} else {
					if (entity instanceof Player _player) {
						_player.getCooldowns().addCooldown(itemstack, 20);
					}
				}
				if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) == (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)) {
					if (world.getDifficulty() == Difficulty.HARD) {
						{
							Entity _ent = entity;
							if (!_ent.level().isClientSide() && _ent.getServer() != null) {
								_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
										_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "effect give @s minecraft:regeneration 10 0 true");
							}
						}
					} else {
						{
							Entity _ent = entity;
							if (!_ent.level().isClientSide() && _ent.getServer() != null) {
								_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
										_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "effect give @s minecraft:regeneration 50 0 true");
							}
						}
					}
				} else {
					if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) <= (entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1)
							+ (itemstack.has(DataComponents.FOOD) ? itemstack.get(DataComponents.FOOD).nutrition() : 0)) {
						{
							Entity _ent = entity;
							if (!_ent.level().isClientSide() && _ent.getServer() != null) {
								_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
										_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "effect give @s minecraft:instant_health 1 2 true");
							}
						}
					} else if (1 <= (itemstack.has(DataComponents.FOOD) ? itemstack.get(DataComponents.FOOD).nutrition() : 0)) {
						if (entity instanceof LivingEntity _entity) {
							_entity.setHealth(((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) + (itemstack.has(DataComponents.FOOD) ? itemstack.get(DataComponents.FOOD).nutrition() : 0)) - 1);
						}
						{
							Entity _ent = entity;
							if (!_ent.level().isClientSide() && _ent.getServer() != null) {
								_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
										_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "/effect give @s minecraft:regeneration 1 2 true");
							}
						}
					} else {
						if (world.getDifficulty() == Difficulty.HARD) {
							{
								Entity _ent = entity;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null,
											4, _ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "effect give @s minecraft:regeneration 10 0 true");
								}
							}
						} else {
							{
								Entity _ent = entity;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null,
											4, _ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "effect give @s minecraft:instant_health 1 0 true");
								}
							}
							{
								Entity _ent = entity;
								if (!_ent.level().isClientSide() && _ent.getServer() != null) {
									_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null,
											4, _ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "effect give @s minecraft:regeneration 50 0 true");
								}
							}
						}
					}
				}
				if (entity instanceof Player _player) {
					ItemStack _stktoremove35 = itemstack;
					_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove35.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
				}
			}
		}
	}
}
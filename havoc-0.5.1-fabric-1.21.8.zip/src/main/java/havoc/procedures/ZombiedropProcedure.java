package havoc.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.Difficulty;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import havoc.init.HavocModItems;

public class ZombiedropProcedure {
	public static boolean eventResult = true;

	public ZombiedropProcedure() {
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, amount) -> {
			if (entity != null) {
				execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
			}
			boolean result = eventResult;
			eventResult = true;
			return result;
		});
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double difficulty_drop_override = 0;
		if (entity instanceof Zoglin || entity instanceof ZombifiedPiglin || entity instanceof Zombie || entity instanceof Husk || entity instanceof Drowned || entity instanceof ZombieVillager) {
			if (world.getDifficulty() == Difficulty.HARD) {
				difficulty_drop_override = 6;
			} else if (world.getDifficulty() == Difficulty.NORMAL) {
				difficulty_drop_override = 2;
			} else {
				difficulty_drop_override = 0;
			}
			if (entity.isOnFire()) {
				for (int index0 = 0; index0 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index0++) {
					if (world.getDifficulty() == Difficulty.HARD) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_10 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTMEAT));
							entityToSpawn_10.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_10);
						}
					} else {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_11 = new ItemEntity(_level, x, y, z, new ItemStack(Items.COOKED_PORKCHOP));
							entityToSpawn_11.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_11);
						}
					}
				}
			} else {
				if (entity instanceof ZombifiedPiglin && !(world.getDifficulty() == Difficulty.HARD)) {
					for (int index1 = 0; index1 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index1++) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_14 = new ItemEntity(_level, x, y, z, new ItemStack(Items.PORKCHOP));
							entityToSpawn_14.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_14);
						}
					}
				} else {
					for (int index2 = 0; index2 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index2++) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_15 = new ItemEntity(_level, x, y, z, new ItemStack(Items.ROTTEN_FLESH));
							entityToSpawn_15.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_15);
						}
					}
				}
			}
			if (world.getDifficulty() == Difficulty.HARD) {
				{
					Entity _ent = entity;
					if (!_ent.level().isClientSide() && _ent.getServer() != null) {
						_ent.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, _ent.position(), _ent.getRotationVector(), _ent.level() instanceof ServerLevel ? (ServerLevel) _ent.level() : null, 4,
								_ent.getName().getString(), _ent.getDisplayName(), _ent.level().getServer(), _ent), "summon minecraft:skeleton ~ ~ ~ {HandItems:[{},{}],ArmorItems:[{},{},{},{}]}");
					}
				}
				if (!entity.level().isClientSide()) {
					entity.discard();
				}
			} else {
				if (entity.isOnFire()) {
					for (int index3 = 0; index3 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index3++) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_20 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
							entityToSpawn_20.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_20);
						}
					}
				} else {
					for (int index4 = 0; index4 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index4++) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_21 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
							entityToSpawn_21.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_21);
						}
					}
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_22 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BRAININFECTED));
						entityToSpawn_22.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_22);
					}
				}
			}
		}
	}
}
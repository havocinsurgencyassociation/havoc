package havoc.procedures;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;

public class VillageronspawnoverrideProcedure {
	public static boolean eventResult = true;

	public VillageronspawnoverrideProcedure() {
		ClientEntityEvents.ENTITY_LOAD.register((entity, world) -> {
			execute();
		});
		ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
			execute();
		});
	}

	public static void execute() {
		double villager_to_spawn = 0;
	}
}
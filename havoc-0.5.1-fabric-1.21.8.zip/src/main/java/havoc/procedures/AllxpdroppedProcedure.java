package havoc.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

public class AllxpdroppedProcedure {
	public static boolean eventResult = true;

	public AllxpdroppedProcedure() {
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, amount) -> {
			if (entity != null) {
				execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
			}
			boolean result = eventResult;
			eventResult = true;
			return result;
		});
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double difficulty_drop_override = 0;
		double total_experience = 0;
		if (entity instanceof Player) {
			if (0 < (entity instanceof Player _plr ? _plr.experienceLevel : 0)) {
				total_experience = entity instanceof Player _plr ? _plr.experienceLevel : 0;
				if (entity instanceof Player _player) {
					_player.giveExperienceLevels(-(entity instanceof Player _plr ? _plr.experienceLevel : 0));
				}
				if (32 < total_experience) {
					total_experience = 4.5 * total_experience * total_experience - 162.5 * total_experience + 2220;
				} else if (16 < total_experience) {
					total_experience = 2.5 * total_experience * total_experience - 40.5 * total_experience + 360;
				} else if (0 < total_experience) {
					total_experience = total_experience * total_experience + 6 * total_experience;
				}
				if (world instanceof ServerLevel _level) {
					_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, (int) (total_experience / 10)));
					_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, (int) (total_experience / 5)));
					_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, (int) (total_experience / 5)));
					_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, (int) (total_experience / 3)));
					_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, (int) (total_experience / 6)));
					_level.addFreshEntity(new ExperienceOrb(_level, x, y, z, 2));
				}
			}
		}
	}
}
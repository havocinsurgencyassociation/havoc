package havoc.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.WanderingTrader;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.monster.piglin.PiglinBrute;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.hoglin.Hoglin;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.animal.wolf.Wolf;
import net.minecraft.world.entity.animal.sniffer.Sniffer;
import net.minecraft.world.entity.animal.sheep.Sheep;
import net.minecraft.world.entity.animal.horse.TraderLlama;
import net.minecraft.world.entity.animal.horse.Mule;
import net.minecraft.world.entity.animal.horse.Llama;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.animal.horse.Donkey;
import net.minecraft.world.entity.animal.goat.Goat;
import net.minecraft.world.entity.animal.frog.Frog;
import net.minecraft.world.entity.animal.camel.Camel;
import net.minecraft.world.entity.animal.axolotl.Axolotl;
import net.minecraft.world.entity.animal.allay.Allay;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.entity.GlowSquid;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.Difficulty;
import net.minecraft.server.level.ServerLevel;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import havoc.init.HavocModItems;
import havoc.init.HavocModBlocks;

public class AnimalmeatoverrideProcedure {
	public static boolean eventResult = true;

	public AnimalmeatoverrideProcedure() {
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, amount) -> {
			if (entity != null) {
				execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
			}
			boolean result = eventResult;
			eventResult = true;
			return result;
		});
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double difficulty_drop_override = 0;
		difficulty_drop_override = 2;
		if (entity instanceof Hoglin || entity instanceof Evoker || entity instanceof Pillager || entity instanceof Ravager || entity instanceof Vindicator || entity instanceof Witch || entity instanceof Piglin || entity instanceof PiglinBrute
				|| entity instanceof Pig || entity instanceof WanderingTrader || entity instanceof Villager) {
			difficulty_drop_override = 3;
			for (int index0 = 0; index0 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index0++) {
				if (entity.isOnFire()) {
					if (world.getDifficulty() == Difficulty.HARD) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_13 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTMEAT));
							entityToSpawn_13.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_13);
							ItemEntity entityToSpawn_14 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
							entityToSpawn_14.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_14);
						}
					} else {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_15 = new ItemEntity(_level, x, y, z, new ItemStack(Items.COOKED_PORKCHOP));
							entityToSpawn_15.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_15);
							ItemEntity entityToSpawn_16 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
							entityToSpawn_16.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_16);
						}
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_17 = new ItemEntity(_level, x, y, z, new ItemStack(Items.PORKCHOP));
						entityToSpawn_17.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_17);
						ItemEntity entityToSpawn_18 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
						entityToSpawn_18.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_18);
					}
				}
			}
			if (entity instanceof Ravager || entity instanceof Pig || entity instanceof Hoglin) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_22 = new ItemEntity(_level, x, y, z, new ItemStack(Items.LEATHER));
					entityToSpawn_22.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_22);
				}
			}
		}
		if (entity instanceof Horse || entity instanceof Sheep || entity instanceof Goat || entity instanceof Mule || entity instanceof Donkey || entity instanceof MushroomCow || entity instanceof Cow || entity instanceof TraderLlama
				|| entity instanceof Llama || entity instanceof Camel || entity instanceof Ocelot || entity instanceof Strider || entity instanceof Fox || entity instanceof Sniffer || entity instanceof Cat || entity instanceof Wolf
				|| entity instanceof PolarBear || entity instanceof Panda) {
			difficulty_drop_override = 3;
			for (int index1 = 0; index1 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index1++) {
				if (entity.isOnFire()) {
					if (world.getDifficulty() == Difficulty.HARD) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_43 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTMEAT));
							entityToSpawn_43.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_43);
							ItemEntity entityToSpawn_44 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
							entityToSpawn_44.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_44);
						}
					} else {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_45 = new ItemEntity(_level, x, y, z, new ItemStack(Items.COOKED_BEEF));
							entityToSpawn_45.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_45);
							ItemEntity entityToSpawn_46 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
							entityToSpawn_46.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_46);
						}
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_47 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BEEF));
						entityToSpawn_47.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_47);
						ItemEntity entityToSpawn_48 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
						entityToSpawn_48.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_48);
					}
				}
			}
		}
		if (entity instanceof Camel || entity instanceof Sheep || entity instanceof Goat || entity instanceof Llama || entity instanceof TraderLlama || entity instanceof Cow || entity instanceof MushroomCow || entity instanceof Donkey
				|| entity instanceof Mule || entity instanceof Horse) {
			if (entity.isOnFire()) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_60 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTMEAT));
					entityToSpawn_60.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_60);
				}
			} else {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_61 = new ItemEntity(_level, x, y, z, new ItemStack(Items.LEATHER));
					entityToSpawn_61.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_61);
				}
			}
		}
		if (entity instanceof Cod || entity instanceof Salmon || entity instanceof TropicalFish || entity instanceof Guardian || entity instanceof ElderGuardian || entity instanceof Turtle || entity instanceof Axolotl || entity instanceof GlowSquid
				|| entity instanceof Dolphin || entity instanceof Squid) {
			difficulty_drop_override = 0;
			for (int index2 = 0; index2 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index2++) {
				if (entity.isOnFire()) {
					if (world.getDifficulty() == Difficulty.HARD) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_74 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTMEAT));
							entityToSpawn_74.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_74);
							ItemEntity entityToSpawn_75 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
							entityToSpawn_75.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_75);
						}
					} else {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_76 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.FISHMEAT));
							entityToSpawn_76.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_76);
							ItemEntity entityToSpawn_77 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE_MEAL));
							entityToSpawn_77.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_77);
						}
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_78 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.FISHMEAT));
						entityToSpawn_78.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_78);
						ItemEntity entityToSpawn_79 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE_MEAL));
						entityToSpawn_79.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_79);
					}
				}
			}
		}
		if (entity instanceof Sheep || entity instanceof Goat) {
			for (int index3 = 0; index3 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index3++) {
				if (entity.isOnFire()) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_83 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_83.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_83);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_84 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModBlocks.BLOODYWOOL));
						entityToSpawn_84.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_84);
					}
				}
			}
		}
		if (entity instanceof Fox) {
			for (int index4 = 0; index4 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index4++) {
				if (entity.isOnFire()) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_87 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_87.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_87);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_88 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.ORANGE_WOOL));
						entityToSpawn_88.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_88);
					}
				}
			}
		}
		if (entity instanceof PolarBear) {
			for (int index5 = 0; index5 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index5++) {
				if (entity.isOnFire()) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_91 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_91.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_91);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_92 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.WHITE_WOOL));
						entityToSpawn_92.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_92);
					}
				}
			}
		}
		if (entity instanceof Wolf) {
			for (int index6 = 0; index6 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index6++) {
				if (entity.isOnFire()) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_95 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_95.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_95);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_96 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.LIGHT_GRAY_WOOL));
						entityToSpawn_96.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_96);
					}
				}
			}
		}
		if (entity instanceof Ocelot) {
			for (int index7 = 0; index7 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index7++) {
				if (entity.isOnFire()) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_99 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_99.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_99);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_100 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.YELLOW_WOOL));
						entityToSpawn_100.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_100);
					}
				}
			}
		}
		if (entity instanceof Panda) {
			for (int index8 = 0; index8 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index8++) {
				if (entity.isOnFire()) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_103 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_103.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_103);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_104 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.BLACK_WOOL));
						entityToSpawn_104.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_104);
					}
				}
			}
		}
		if (entity instanceof Allay) {
			for (int index9 = 0; index9 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index9++) {
				if (entity.isOnFire()) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_107 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_107.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_107);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_108 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.LIGHT_BLUE_WOOL));
						entityToSpawn_108.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_108);
					}
				}
			}
		}
		if (entity instanceof Parrot || entity instanceof Chicken) {
			if (entity.isOnFire()) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_112 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTMEAT));
					entityToSpawn_112.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_112);
				}
				for (int index10 = 0; index10 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index10++) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_113 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_113.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_113);
					}
				}
			} else {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_114 = new ItemEntity(_level, x, y, z, new ItemStack(Items.CHICKEN));
					entityToSpawn_114.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_114);
				}
				for (int index11 = 0; index11 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index11++) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_115 = new ItemEntity(_level, x, y, z, new ItemStack(Items.FEATHER));
						entityToSpawn_115.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_115);
					}
				}
			}
		}
		if (entity instanceof Rabbit) {
			if (entity.isOnFire()) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_118 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTMEAT));
					entityToSpawn_118.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_118);
				}
				for (int index12 = 0; index12 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index12++) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_119 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_119.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_119);
					}
				}
			} else {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_120 = new ItemEntity(_level, x, y, z, new ItemStack(Items.RABBIT));
					entityToSpawn_120.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_120);
					ItemEntity entityToSpawn_121 = new ItemEntity(_level, x, y, z, new ItemStack(Items.RABBIT_HIDE));
					entityToSpawn_121.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_121);
					ItemEntity entityToSpawn_122 = new ItemEntity(_level, x, y, z, new ItemStack(Items.RABBIT_FOOT));
					entityToSpawn_122.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_122);
					ItemEntity entityToSpawn_123 = new ItemEntity(_level, x, y, z, new ItemStack(Items.RABBIT_FOOT));
					entityToSpawn_123.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_123);
				}
			}
		}
		if (entity instanceof Turtle) {
			for (int index13 = 0; index13 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index13++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_125 = new ItemEntity(_level, x, y, z, new ItemStack(Items.TURTLE_SCUTE));
					entityToSpawn_125.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_125);
				}
			}
		}
		if (entity instanceof Pufferfish) {
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn_127 = new ItemEntity(_level, x, y, z, new ItemStack(Items.PUFFERFISH));
				entityToSpawn_127.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn_127);
			}
		}
		if (entity instanceof Bat) {
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn_129 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.BLACK_WOOL));
				entityToSpawn_129.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn_129);
			}
		}
		if (entity instanceof Frog) {
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn_131 = new ItemEntity(_level, x, y, z, new ItemStack(Items.CHICKEN));
				entityToSpawn_131.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn_131);
			}
		}
	}
}
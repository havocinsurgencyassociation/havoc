package havoc.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.piglin.PiglinBrute;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerLevel;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

public class Droparmornitems100Procedure {
	public static boolean eventResult = true;

	public Droparmornitems100Procedure() {
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, amount) -> {
			if (entity != null) {
				execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
			}
			boolean result = eventResult;
			eventResult = true;
			return result;
		});
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double difficulty_drop_override = 0;
		if (entity instanceof PiglinBrute || entity instanceof Piglin || entity instanceof Skeleton || entity instanceof Stray || entity instanceof ZombifiedPiglin || entity instanceof Zombie || entity instanceof Husk || entity instanceof Drowned
				|| entity instanceof ZombieVillager) {
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn_10 = new ItemEntity(_level, x, y, z, (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY));
				entityToSpawn_10.setPickUpDelay(10);
				entityToSpawn_10.setUnlimitedLifetime();
				_level.addFreshEntity(entityToSpawn_10);
				ItemEntity entityToSpawn_12 = new ItemEntity(_level, x, y, z, (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY));
				entityToSpawn_12.setPickUpDelay(10);
				entityToSpawn_12.setUnlimitedLifetime();
				_level.addFreshEntity(entityToSpawn_12);
				ItemEntity entityToSpawn_14 = new ItemEntity(_level, x, y, z, (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.FEET) : ItemStack.EMPTY));
				entityToSpawn_14.setPickUpDelay(10);
				entityToSpawn_14.setUnlimitedLifetime();
				_level.addFreshEntity(entityToSpawn_14);
				ItemEntity entityToSpawn_16 = new ItemEntity(_level, x, y, z, (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.LEGS) : ItemStack.EMPTY));
				entityToSpawn_16.setPickUpDelay(10);
				entityToSpawn_16.setUnlimitedLifetime();
				_level.addFreshEntity(entityToSpawn_16);
				ItemEntity entityToSpawn_18 = new ItemEntity(_level, x, y, z, (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.CHEST) : ItemStack.EMPTY));
				entityToSpawn_18.setPickUpDelay(10);
				entityToSpawn_18.setUnlimitedLifetime();
				_level.addFreshEntity(entityToSpawn_18);
				ItemEntity entityToSpawn_20 = new ItemEntity(_level, x, y, z, (entity instanceof LivingEntity _entGetArmor ? _entGetArmor.getItemBySlot(EquipmentSlot.HEAD) : ItemStack.EMPTY));
				entityToSpawn_20.setPickUpDelay(10);
				entityToSpawn_20.setUnlimitedLifetime();
				_level.addFreshEntity(entityToSpawn_20);
			}
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack21 = new ItemStack(Blocks.AIR).copy();
				_setstack21.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack21);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
				ItemStack _setstack22 = new ItemStack(Blocks.AIR).copy();
				_setstack22.setCount(1);
				_entity.setItemInHand(InteractionHand.OFF_HAND, _setstack22);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
			if (entity instanceof LivingEntity _living) {
				_living.setItemSlot(EquipmentSlot.FEET, new ItemStack(Blocks.AIR));
				_living.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Blocks.AIR));
				_living.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Blocks.AIR));
				_living.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Blocks.AIR));
			}
		}
	}
}
package havoc.procedures;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;

public class BedbreakerclientProcedure {
	public static boolean eventResult = true;

	public BedbreakerclientProcedure() {
		UseBlockCallback.EVENT.register((player, level, hand, hitResult) -> {
			if (hand == player.getUsedItemHand())
				execute(level, hitResult.getBlockPos().getX(), hitResult.getBlockPos().getY(), hitResult.getBlockPos().getZ(), player);
			boolean result = eventResult;
			eventResult = true;
			return result ? InteractionResult.PASS : InteractionResult.FAIL;
		});
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double randomtext = 0;
		if ((world.getBlockState(BlockPos.containing(x, y, z))).is(TagKey.create(Registries.BLOCK, ResourceLocation.parse("minecraft:beds")))) {
			if ((entity.level().dimension()) == Level.NETHER || (entity.level().dimension()) == Level.END) {
				{
					BlockPos _pos = BlockPos.containing(x, y, z);
					Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
					world.destroyBlock(_pos, false);
				}
				randomtext = Mth.nextInt(RandomSource.create(), 0, 2);
				if (1 == randomtext) {
					if (entity instanceof Player _player && !_player.level().isClientSide()) {
						_player.displayClientMessage(Component.literal("No amount of rest can pass this nightmare"), true);
					}
				} else if (2 == randomtext) {
					if (entity instanceof Player _player && !_player.level().isClientSide()) {
						_player.displayClientMessage(Component.literal("You may not rest now; you are not alone"), true);
					}
					if (world instanceof Level _level) {
						if (!_level.isClientSide()) {
							_level.playSound(null, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -2, 2), y + Mth.nextInt(RandomSource.create(), 4, 12), z + Mth.nextInt(RandomSource.create(), -2, 2)),
									BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.cave")), SoundSource.AMBIENT, (float) 0.5, 1);
						} else {
							_level.playLocalSound((x + Mth.nextInt(RandomSource.create(), -2, 2)), (y + Mth.nextInt(RandomSource.create(), 4, 12)), (z + Mth.nextInt(RandomSource.create(), -2, 2)),
									BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.cave")), SoundSource.AMBIENT, (float) 0.5, 1, false);
						}
					}
				} else {
					if (entity instanceof Player _player && !_player.level().isClientSide()) {
						_player.displayClientMessage(Component.literal("[Intentional Game Design]"), true);
					}
				}
				if (entity instanceof LivingEntity _entity) {
					_entity.swing(InteractionHand.MAIN_HAND, true);
				}
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -20, 20), y, z + Mth.nextInt(RandomSource.create(), -20, 20)), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.cave")),
								SoundSource.AMBIENT, (float) 0.1, 1);
					} else {
						_level.playLocalSound((x + Mth.nextInt(RandomSource.create(), -20, 20)), y, (z + Mth.nextInt(RandomSource.create(), -20, 20)), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ambient.cave")),
								SoundSource.AMBIENT, (float) 0.1, 1, false);
					}
				}
			}
		}
	}
}
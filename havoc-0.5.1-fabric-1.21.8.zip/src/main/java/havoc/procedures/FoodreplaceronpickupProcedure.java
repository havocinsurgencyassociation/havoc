package havoc.procedures;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import havoc.init.HavocModItems;

import havoc.event.LivingEntityEvents;

public class FoodreplaceronpickupProcedure {
	public static boolean eventResult = true;

	public FoodreplaceronpickupProcedure() {
		LivingEntityEvents.ENTITY_PICKUP_ITEM.register((entity, itemstack) -> {
			execute(entity);
		});
	}

	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player) {
			while (true) {
				if (hasEntityInInventory(entity, new ItemStack(Items.APPLE))) {
					if (entity instanceof Player _player) {
						ItemStack _stktoremove2 = new ItemStack(Items.APPLE);
						_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove2.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
					}
					if (entity instanceof Player _player) {
						ItemStack _setstack = new ItemStack(HavocModItems.APPLE).copy();
						_setstack.setCount(1);
						_player.addItem(_setstack);
					}
				} else if (hasEntityInInventory(entity, new ItemStack(Items.GOLDEN_APPLE))) {
					if (entity instanceof Player _player) {
						ItemStack _stktoremove5 = new ItemStack(Items.GOLDEN_APPLE);
						_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove5.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
					}
					if (entity instanceof Player _player) {
						ItemStack _setstack = new ItemStack(HavocModItems.GOLDEN_APPLE).copy();
						_setstack.setCount(1);
						_player.addItem(_setstack);
					}
				} else if (hasEntityInInventory(entity, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE))) {
					if (entity instanceof Player _player) {
						ItemStack _stktoremove8 = new ItemStack(Items.ENCHANTED_GOLDEN_APPLE);
						_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove8.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
					}
					if (entity instanceof Player _player) {
						ItemStack _setstack = new ItemStack(HavocModItems.ENCHANTED_GOLDEN_APPLE).copy();
						_setstack.setCount(1);
						_player.addItem(_setstack);
					}
				} else {
					break;
				}
			}
		}
	}

	private static boolean hasEntityInInventory(Entity entity, ItemStack itemstack) {
		if (entity instanceof Player player)
			return player.getInventory().contains(stack -> !stack.isEmpty() && ItemStack.isSameItem(stack, itemstack));
		return false;
	}
}
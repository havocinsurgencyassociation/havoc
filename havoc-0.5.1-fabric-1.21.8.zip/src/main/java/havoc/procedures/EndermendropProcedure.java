package havoc.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

public class EndermendropProcedure {
	public static boolean eventResult = true;

	public EndermendropProcedure() {
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, amount) -> {
			if (entity != null) {
				execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
			}
			boolean result = eventResult;
			eventResult = true;
			return result;
		});
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double difficulty_drop_override = 0;
		if (entity instanceof EnderMan) {
			if (entity instanceof Mob _mobEnt1 && _mobEnt1.isAggressive()) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_2 = new ItemEntity(_level, x, y, z, new ItemStack(Items.ENDER_PEARL));
					entityToSpawn_2.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_2);
				}
			}
		}
	}
}
package havoc.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.animal.horse.SkeletonHorse;
import net.minecraft.world.entity.animal.Squid;
import net.minecraft.world.entity.animal.SnowGolem;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.animal.Bee;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.GlowSquid;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.Difficulty;
import net.minecraft.server.level.ServerLevel;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import havoc.init.HavocModItems;

public class MiscdropoverrideProcedure {
	public static boolean eventResult = true;

	public MiscdropoverrideProcedure() {
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, amount) -> {
			if (entity != null) {
				execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
			}
			boolean result = eventResult;
			eventResult = true;
			return result;
		});
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double difficulty_drop_override = 0;
		difficulty_drop_override = 4;
		if (entity instanceof SkeletonHorse) {
			for (int index0 = 0; index0 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index0++) {
				if (entity.isOnFire()) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_2 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_2.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_2);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_3 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
						entityToSpawn_3.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_3);
					}
				}
			}
		}
		if (entity instanceof SnowGolem) {
			for (int index1 = 0; index1 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index1++) {
				if (!entity.isOnFire()) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_6 = new ItemEntity(_level, x, y, z, new ItemStack(Items.SNOWBALL));
						entityToSpawn_6.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_6);
					}
				}
			}
		}
		if (entity instanceof IronGolem) {
			if (!entity.isOnFire()) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_9 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.POPPY));
					entityToSpawn_9.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_9);
				}
			}
		}
		if (entity instanceof Blaze) {
			for (int index2 = 0; index2 < (int) Math.round(difficulty_drop_override * Math.random() + 5); index2++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_11 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BLAZE_ROD));
					entityToSpawn_11.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_11);
				}
			}
		}
		if (entity instanceof Bee) {
			if (!entity.isOnFire()) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_14 = new ItemEntity(_level, x, y, z, new ItemStack(Items.HONEYCOMB));
					entityToSpawn_14.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_14);
				}
			}
		}
		if (entity instanceof WitherBoss) {
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn_16 = new ItemEntity(_level, x, y, z, new ItemStack(Items.NETHER_STAR));
				entityToSpawn_16.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn_16);
			}
		}
		if (entity instanceof EnderDragon) {
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn_18 = new ItemEntity(_level, x, y, z, new ItemStack(Items.DRAGON_HEAD));
				entityToSpawn_18.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn_18);
				ItemEntity entityToSpawn_19 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.DRAGON_EGG));
				entityToSpawn_19.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn_19);
			}
			for (int index3 = 0; index3 < Math.round(15 * Math.random() + 1); index3++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_20 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BEEF));
					entityToSpawn_20.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_20);
				}
			}
			for (int index4 = 0; index4 < Math.round(15 * Math.random() + 1); index4++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_21 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
					entityToSpawn_21.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_21);
				}
			}
			for (int index5 = 0; index5 < Math.round(15 * Math.random() + 1); index5++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_22 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.BLACK_WOOL));
					entityToSpawn_22.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_22);
				}
			}
		}
		if (entity instanceof Shulker) {
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn_24 = new ItemEntity(_level, x, y, z, new ItemStack(Items.SHULKER_SHELL));
				entityToSpawn_24.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn_24);
				ItemEntity entityToSpawn_25 = new ItemEntity(_level, x, y, z, new ItemStack(Items.SHULKER_SHELL));
				entityToSpawn_25.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn_25);
			}
		}
		if (entity instanceof Phantom) {
			if (!entity.level().isClientSide()) {
				entity.discard();
			}
		}
		if (entity instanceof Vex) {
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn_30 = new ItemEntity(_level, x, y, z, (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY));
				entityToSpawn_30.setPickUpDelay(10);
				entityToSpawn_30.setUnlimitedLifetime();
				_level.addFreshEntity(entityToSpawn_30);
			}
		}
		if (entity instanceof EnderMan) {
			for (int index6 = 0; index6 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index6++) {
				if (entity.isOnFire()) {
					if (world.getDifficulty() == Difficulty.HARD) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_34 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTMEAT));
							entityToSpawn_34.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_34);
							ItemEntity entityToSpawn_35 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
							entityToSpawn_35.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_35);
						}
					} else {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_36 = new ItemEntity(_level, x, y, z, new ItemStack(Items.COOKED_MUTTON));
							entityToSpawn_36.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_36);
							ItemEntity entityToSpawn_37 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
							entityToSpawn_37.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_37);
						}
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_38 = new ItemEntity(_level, x, y, z, new ItemStack(Items.ROTTEN_FLESH));
						entityToSpawn_38.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_38);
						ItemEntity entityToSpawn_39 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
						entityToSpawn_39.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_39);
					}
				}
			}
		}
		if (entity instanceof Endermite) {
			if (entity.isOnFire()) {
				if (world.getDifficulty() == Difficulty.HARD) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_43 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTMEAT));
						entityToSpawn_43.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_43);
						ItemEntity entityToSpawn_44 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_44.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_44);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_45 = new ItemEntity(_level, x, y, z, new ItemStack(Items.COOKED_MUTTON));
						entityToSpawn_45.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_45);
						ItemEntity entityToSpawn_46 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
						entityToSpawn_46.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_46);
					}
				}
			} else {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_47 = new ItemEntity(_level, x, y, z, new ItemStack(Items.ROTTEN_FLESH));
					entityToSpawn_47.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_47);
					ItemEntity entityToSpawn_48 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
					entityToSpawn_48.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_48);
				}
			}
		}
		if (entity instanceof Silverfish) {
			if (entity.isOnFire()) {
				if (world.getDifficulty() == Difficulty.HARD) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_52 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTMEAT));
						entityToSpawn_52.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_52);
						ItemEntity entityToSpawn_53 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_53.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_53);
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_54 = new ItemEntity(_level, x, y, z, new ItemStack(Items.COOKED_SALMON));
						entityToSpawn_54.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_54);
						ItemEntity entityToSpawn_55 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE_MEAL));
						entityToSpawn_55.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_55);
					}
				}
			} else {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_56 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.FISHMEAT));
					entityToSpawn_56.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_56);
					ItemEntity entityToSpawn_57 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE_MEAL));
					entityToSpawn_57.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_57);
				}
			}
		}
		if (entity instanceof Spider || entity instanceof CaveSpider) {
			for (int index7 = 0; index7 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index7++) {
				if (entity.isOnFire()) {
					if (world.getDifficulty() == Difficulty.HARD) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_62 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
							entityToSpawn_62.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_62);
						}
					} else {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_63 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
							entityToSpawn_63.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_63);
							ItemEntity entityToSpawn_64 = new ItemEntity(_level, x, y, z, new ItemStack(Items.STRING));
							entityToSpawn_64.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_64);
						}
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_65 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
						entityToSpawn_65.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_65);
						ItemEntity entityToSpawn_66 = new ItemEntity(_level, x, y, z, new ItemStack(Items.STRING));
						entityToSpawn_66.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_66);
					}
				}
			}
		}
		if (entity instanceof MagmaCube) {
			for (int index8 = 0; index8 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index8++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_68 = new ItemEntity(_level, x, y, z, new ItemStack(Items.MAGMA_CREAM));
					entityToSpawn_68.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_68);
				}
			}
		} else if (entity instanceof Slime) {
			for (int index9 = 0; index9 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index9++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_70 = new ItemEntity(_level, x, y, z, new ItemStack(Items.SLIME_BALL));
					entityToSpawn_70.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_70);
				}
			}
		}
		if (entity instanceof Creeper) {
			for (int index10 = 0; index10 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index10++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_72 = new ItemEntity(_level, x, y, z, new ItemStack(Blocks.KELP));
					entityToSpawn_72.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_72);
				}
			}
		}
		if (entity instanceof WitherSkeleton) {
			for (int index11 = 0; index11 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index11++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_74 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BURNTBONES));
					entityToSpawn_74.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_74);
				}
			}
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn_75 = new ItemEntity(_level, x, y, z, new ItemStack(Items.WITHER_SKELETON_SKULL));
				entityToSpawn_75.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn_75);
			}
		}
		if (entity instanceof Warden) {
			for (int index12 = 0; index12 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index12++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_77 = new ItemEntity(_level, x, y, z, new ItemStack(Items.ROTTEN_FLESH));
					entityToSpawn_77.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_77);
				}
			}
			for (int index13 = 0; index13 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index13++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_78 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
					entityToSpawn_78.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_78);
				}
			}
		}
		if (entity instanceof Ghast) {
			for (int index14 = 0; index14 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index14++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_80 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BEEF));
					entityToSpawn_80.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_80);
				}
			}
			for (int index15 = 0; index15 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index15++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_81 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
					entityToSpawn_81.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_81);
				}
			}
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn_82 = new ItemEntity(_level, x, y, z, new ItemStack(Items.GHAST_TEAR));
				entityToSpawn_82.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn_82);
			}
		}
		if (entity instanceof Squid) {
			for (int index16 = 0; index16 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index16++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_84 = new ItemEntity(_level, x, y, z, new ItemStack(Items.INK_SAC));
					entityToSpawn_84.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_84);
				}
			}
		} else if (entity instanceof GlowSquid) {
			for (int index17 = 0; index17 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index17++) {
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn_86 = new ItemEntity(_level, x, y, z, new ItemStack(Items.GLOW_INK_SAC));
					entityToSpawn_86.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn_86);
				}
			}
		}
	}
}
package havoc.procedures;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import havoc.network.HavocModVariables;

import havoc.init.HavocModItems;

import havoc.event.PlayerEvents;

public class FoodreplacerProcedure {
	public static boolean eventResult = true;

	public FoodreplacerProcedure() {
		PlayerEvents.END_PLAYER_TICK.register(entity -> {
			execute(entity);
		});
	}

	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (HavocModVariables.havoc_tick % 128 == 0) {
			while (true) {
				if (hasEntityInInventory(entity, new ItemStack(Items.APPLE))) {
					if (entity instanceof Player _player) {
						ItemStack _stktoremove1 = new ItemStack(Items.APPLE);
						_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove1.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
					}
					if (entity instanceof Player _player) {
						ItemStack _setstack = new ItemStack(HavocModItems.APPLE).copy();
						_setstack.setCount(1);
						_player.addItem(_setstack);
					}
				} else if (hasEntityInInventory(entity, new ItemStack(Items.GOLDEN_APPLE))) {
					if (entity instanceof Player _player) {
						ItemStack _stktoremove4 = new ItemStack(Items.GOLDEN_APPLE);
						_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove4.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
					}
					if (entity instanceof Player _player) {
						ItemStack _setstack = new ItemStack(HavocModItems.GOLDEN_APPLE).copy();
						_setstack.setCount(1);
						_player.addItem(_setstack);
					}
				} else if (hasEntityInInventory(entity, new ItemStack(Items.ENCHANTED_GOLDEN_APPLE))) {
					if (entity instanceof Player _player) {
						ItemStack _stktoremove7 = new ItemStack(Items.ENCHANTED_GOLDEN_APPLE);
						_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove7.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
					}
					if (entity instanceof Player _player) {
						ItemStack _setstack = new ItemStack(HavocModItems.ENCHANTED_GOLDEN_APPLE).copy();
						_setstack.setCount(1);
						_player.addItem(_setstack);
					}
				} else {
					break;
				}
			}
		}
	}

	private static boolean hasEntityInInventory(Entity entity, ItemStack itemstack) {
		if (entity instanceof Player player)
			return player.getInventory().contains(stack -> !stack.isEmpty() && ItemStack.isSameItem(stack, itemstack));
		return false;
	}
}
package havoc.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.monster.Stray;
import net.minecraft.world.entity.monster.Skeleton;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.Difficulty;
import net.minecraft.server.level.ServerLevel;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;

import havoc.init.HavocModItems;

public class SkeletonmodProcedure {
	public static boolean eventResult = true;

	public SkeletonmodProcedure() {
		ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, amount) -> {
			if (entity != null) {
				execute(entity.level(), entity.getX(), entity.getY(), entity.getZ(), entity);
			}
			boolean result = eventResult;
			eventResult = true;
			return result;
		});
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double difficulty_drop_override = 0;
		if (entity instanceof Skeleton || entity instanceof Stray) {
			if (world.getDifficulty() == Difficulty.HARD) {
				difficulty_drop_override = 6;
			} else if (world.getDifficulty() == Difficulty.HARD) {
				difficulty_drop_override = 4;
			} else {
				difficulty_drop_override = 0;
			}
			if (entity.isOnFire()) {
				for (int index0 = 0; index0 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index0++) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_5 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
						entityToSpawn_5.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_5);
					}
				}
			} else {
				for (int index1 = 0; index1 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index1++) {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_6 = new ItemEntity(_level, x, y, z, new ItemStack(Items.BONE));
						entityToSpawn_6.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_6);
					}
				}
			}
			if (entity instanceof Skeleton) {
				if (entity.isOnFire()) {
					for (int index2 = 0; index2 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index2++) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_9 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
							entityToSpawn_9.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_9);
						}
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_10 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BRAININFECTED));
						entityToSpawn_10.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_10);
					}
				}
			} else if (entity instanceof Stray) {
				if (entity.isOnFire()) {
					for (int index3 = 0; index3 < (int) Math.round(difficulty_drop_override * Math.random() + 1); index3++) {
						if (world instanceof ServerLevel _level) {
							ItemEntity entityToSpawn_13 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.ASH));
							entityToSpawn_13.setPickUpDelay(10);
							_level.addFreshEntity(entityToSpawn_13);
						}
					}
				} else {
					if (world instanceof ServerLevel _level) {
						ItemEntity entityToSpawn_14 = new ItemEntity(_level, x, y, z, new ItemStack(HavocModItems.BRAININFECTED));
						entityToSpawn_14.setPickUpDelay(10);
						_level.addFreshEntity(entityToSpawn_14);
					}
				}
			}
		}
	}
}
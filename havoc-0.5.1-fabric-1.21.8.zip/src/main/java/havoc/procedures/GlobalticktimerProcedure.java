package havoc.procedures;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import havoc.network.HavocModVariables;

public class GlobalticktimerProcedure {
	public static boolean eventResult = true;

	public GlobalticktimerProcedure() {
		ServerTickEvents.END_WORLD_TICK.register((level) -> {
			execute();
		});
	}

	public static void execute() {
		if (1022 < HavocModVariables.havoc_tick) {
			HavocModVariables.havoc_tick = HavocModVariables.havoc_tick + 1;
		} else {
			HavocModVariables.havoc_tick = 0;
		}
	}
}
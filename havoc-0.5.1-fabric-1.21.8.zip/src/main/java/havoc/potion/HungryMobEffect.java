package havoc.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.InstantenousMobEffect;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

public class HungryMobEffect extends InstantenousMobEffect {
	public HungryMobEffect() {
		super(MobEffectCategory.HARMFUL, -16777216);
		this.withSoundOnAdded(BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("entity.player.burp")));
	}
}
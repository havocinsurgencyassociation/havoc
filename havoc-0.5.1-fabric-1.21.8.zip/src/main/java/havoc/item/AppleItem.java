package havoc.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;

import havoc.procedures.HealthfromfoodProcedure;

public class AppleItem extends Item {
	public AppleItem(Item.Properties properties) {
		super(properties.stacksTo(4).food((new FoodProperties.Builder()).nutrition(4).saturationModifier(0f).alwaysEdible().build()));
	}

	@Override
	public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
		ItemStack retval = super.finishUsingItem(itemstack, world, entity);
		HealthfromfoodProcedure.execute(world, entity, itemstack);
		return retval;
	}
}
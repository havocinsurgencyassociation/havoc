package havoc.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;

import havoc.procedures.HealthfromfoodProcedure;

public class GoldenAppleItem extends Item {
	public GoldenAppleItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON).stacksTo(4).food((new FoodProperties.Builder()).nutrition(20).saturationModifier(0f).alwaysEdible().build()));
	}

	@Override
	public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
		ItemStack retval = super.finishUsingItem(itemstack, world, entity);
		HealthfromfoodProcedure.execute(world, entity, itemstack);
		return retval;
	}
}
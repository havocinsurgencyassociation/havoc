package havoc.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;

import havoc.procedures.HealthfromfoodProcedure;

public class GlowBerriesItem extends Item {
	public GlowBerriesItem(Item.Properties properties) {
		super(properties.stacksTo(16).food((new FoodProperties.Builder()).nutrition(2).saturationModifier(0f).alwaysEdible().build(), Consumables.defaultFood().consumeSeconds(0.2F).build()));
	}

	@Override
	public ItemStack finishUsingItem(ItemStack itemstack, Level world, LivingEntity entity) {
		ItemStack retval = super.finishUsingItem(itemstack, world, entity);
		HealthfromfoodProcedure.execute(world, entity, itemstack);
		return retval;
	}
}
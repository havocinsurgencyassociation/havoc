package havoc.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import havoc.init.HavocModFluids;

public class SpacewaterItem extends BucketItem {
	public SpacewaterItem(Item.Properties properties) {
		super(HavocModFluids.SPACEWATER, properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}